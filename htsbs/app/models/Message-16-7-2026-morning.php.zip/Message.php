<?php

require_once __DIR__ . '/../../config/database.php';

class Message
{
    private $db;

    public function __construct()
    {
        $this->db =
        (new Database())->connect();
    }

    /*
    إرسال رسالة
    */
    public function send(
        $senderId,
        $receiverId,
        $subject,
        $message
    )
    {
        $stmt = $this->db->prepare(

        "INSERT INTO messages
        (
            sender_id,
            receiver_id,
            subject,
            message
        )
        VALUES
        (
            ?,?,?,?
        )"

        );

        return $stmt->execute([

            $senderId,
            $receiverId,
            $subject,
            $message

        ]);
    }

    /*
    صندوق الوارد
    */
           public function inbox($userId)
        {
        $stmt = $this->db->prepare(
        
        
        "SELECT
        
            m.*,
        
            u.full_name AS sender_name,
            u.role_id,
        
            d.department_name,
            c.class_name
        
        FROM messages m
        
        INNER JOIN users u
            ON m.sender_id = u.id
        
        LEFT JOIN teachers t
            ON u.id = t.user_id
        
        LEFT JOIN departments d
            ON t.department_id = d.id
        
        LEFT JOIN students s
            ON u.id = s.user_id
        
        LEFT JOIN classes c
            ON s.class_id = c.id
        
        WHERE m.receiver_id = ?
        
        ORDER BY m.created_at DESC"
        
        );
        
        $stmt->execute([
            $userId
        ]);
        
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        
        }


    /*
    الرسائل المرسلة
    */
    public function sent($userId)
    {
        $stmt = $this->db->prepare(

        "SELECT

            m.*,
            u.full_name AS receiver_name

        FROM messages m

        INNER JOIN users u
        ON m.receiver_id = u.id

        WHERE m.sender_id=?

        ORDER BY m.created_at DESC"

        );

        $stmt->execute([
            $userId
        ]);

        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    /*
    عرض رسالة
    */
                public function find($id)
            {
            $stmt = $this->db->prepare(
            
            
            "SELECT
            
                m.*,
            
                s.full_name AS sender_name,
                s.role_id AS sender_role,
            
                r.full_name AS receiver_name,
            
                d.department_name,
                c.class_name
            
            FROM messages m
            
            INNER JOIN users s
                ON m.sender_id = s.id
            
            INNER JOIN users r
                ON m.receiver_id = r.id
            
            LEFT JOIN teachers t
                ON s.id = t.user_id
            
            LEFT JOIN departments d
                ON t.department_id = d.id
            
            LEFT JOIN students st
                ON s.id = st.user_id
            
            LEFT JOIN classes c
                ON st.class_id = c.id
            
            WHERE m.id = ?"
            
            );
            
            $stmt->execute([
                $id
            ]);
            
            return $stmt->fetch(PDO::FETCH_ASSOC);
            
            
            }


    /*
    تعليم كمقروءة
    */
    public function markRead($id)
    {
        $stmt = $this->db->prepare(

        "UPDATE messages
         SET is_read=1
         WHERE id=?"

        );

        return $stmt->execute([
            $id
        ]);
    }

    /*
    حذف رسالة
    */
    public function delete($id)
    {
        $stmt = $this->db->prepare(

        "DELETE FROM messages
         WHERE id=?"

        );

        return $stmt->execute([
            $id
        ]);
    }

    /*
    عدد الرسائل غير المقروءة
    */
    public function unreadCount($userId)
    {
        $stmt = $this->db->prepare(

        "SELECT COUNT(*) total

         FROM messages

         WHERE receiver_id=?
         AND is_read=0"

        );

        $stmt->execute([
            $userId
        ]);

        return $stmt->fetch()['total'];
    }
}
?>
