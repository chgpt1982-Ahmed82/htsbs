<?php

define(
    'OPENAI_API_KEY',
    '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'
);

define('OPENAI_MODEL', 'gpt-5.5');
?>
